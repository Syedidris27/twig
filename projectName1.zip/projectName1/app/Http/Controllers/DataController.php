<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DataController extends Controller
{
    public function showData()
    {
        $summaryData = json_decode(Storage::get('summary.json'), true);
        $whatsNewData = json_decode(Storage::get('Whats_New.json'), true);
        $latestActivityData = json_decode(Storage::get('Latest_Activity.json'), true);
        $newProductsData = json_decode(Storage::get('New_Products.json'), true);
        $projectprogresssummary = json_decode(Storage::get('Project_Progress_Summary.json'), true);

        // echo "<pre>"; print_r($whatsNewData['what_new_items']); echo "</pre";
        return view('data', [
        'summary' => $summaryData['summary'],
        'whatsNewData'=>$whatsNewData['what_new_items'],
        'latestActivityData'=>$latestActivityData['latest_activity'],
        'newProductsData'=>$newProductsData['new_products'],
        'project_progress_summary'=> $projectprogresssummary['project_progress_summary']
    ]);
    }
}
